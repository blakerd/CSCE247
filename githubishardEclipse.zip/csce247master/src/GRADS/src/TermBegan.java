package GRADS.src;

import GRADS.src.GRADSResources.EnumHandler.SemesterEnum;

public class TermBegan extends Term {

    public TermBegan() {
        super();
    }

    public TermBegan(SemesterEnum semester, int year) {
        super(semester, year);
    }

}
